
__version__ = "1.0.0"
__author__ = 'Caleb OConnor'
__credits__ = 'MD Anderson Cancer Center'
